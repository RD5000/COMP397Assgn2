module config {
    export enum Scene {
        START,
        PLAY,
        END
    }
}