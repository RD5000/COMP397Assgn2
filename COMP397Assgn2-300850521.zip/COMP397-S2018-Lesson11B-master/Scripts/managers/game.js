var managers;
(function (managers) {
    var Game = /** @class */ (function () {
        function Game() {
        }
        return Game;
    }());
    managers.Game = Game;
})(managers || (managers = {}));
//# sourceMappingURL=game.js.map